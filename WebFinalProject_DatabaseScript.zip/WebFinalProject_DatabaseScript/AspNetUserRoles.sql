INSERT INTO [AspNetUserRoles] VALUES (N'38a94ea2-a627-484d-9b90-4a65a7b23908', N'1ed948c3-7b1e-441b-8fb9-6a5315ef2cdb'); GO
INSERT INTO [AspNetUserRoles] VALUES (N'9fda1e03-f5fe-4c72-8e6c-62f6b94a14ea', N'1ed948c3-7b1e-441b-8fb9-6a5315ef2cdb'); GO
INSERT INTO [AspNetUserRoles] VALUES (N'2986557a-f518-4144-86d2-527afed6bead', N'2aeccb4b-2fc9-407f-acf9-4c795badbd55'); GO
INSERT INTO [AspNetUserRoles] VALUES (N'd2f52e60-3586-47c1-af74-9e6bb5cb9c57', N'2aeccb4b-2fc9-407f-acf9-4c795badbd55'); GO
INSERT INTO [AspNetUserRoles] VALUES (N'd8667a3c-e5f6-42c1-aee4-28b57548f75f', N'2aeccb4b-2fc9-407f-acf9-4c795badbd55'); GO
INSERT INTO [AspNetUserRoles] VALUES (N'e3027eae-c372-4cae-9d32-33223055b70c', N'2aeccb4b-2fc9-407f-acf9-4c795badbd55'); GO
