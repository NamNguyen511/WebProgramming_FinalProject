INSERT INTO [__EFMigrationsHistory] VALUES (N'20191128024410_ComplexDataModel', N'3.0.1'); GO
