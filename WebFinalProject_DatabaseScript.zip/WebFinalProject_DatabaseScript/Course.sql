INSERT INTO [Course] VALUES (1045, N'Technical English', 2, 3); GO
INSERT INTO [Course] VALUES (1050, N'Information Security', 3, 4); GO
INSERT INTO [Course] VALUES (2021, N'Calculus 3', 3, 2); GO
INSERT INTO [Course] VALUES (2042, N'Literature', 2, 3); GO
INSERT INTO [Course] VALUES (2050, N'Network Essential', 3, 1); GO
INSERT INTO [Course] VALUES (3141, N'Calculus 2', 3, 2); GO
