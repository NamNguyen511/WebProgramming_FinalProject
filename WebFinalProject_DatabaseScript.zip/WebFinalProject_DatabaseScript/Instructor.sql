INSERT INTO [Instructor] VALUES (1, N'Quang', N'Nguyen Dang', N'1999-02-02 00:00:00.0000000'); GO
INSERT INTO [Instructor] VALUES (2, N'Bao', N'Nguyen Thien', N'2002-05-03 00:00:00.0000000'); GO
INSERT INTO [Instructor] VALUES (3, N'Quyen', N'Nguyen Van', N'1995-01-01 00:00:00.0000000'); GO
INSERT INTO [Instructor] VALUES (4, N'Thi Van', N'Nguyen Tran', N'2001-11-09 00:00:00.0000000'); GO
INSERT INTO [Instructor] VALUES (6, N'Khoan', N'Nguyen Duc', N'2000-04-14 00:00:00.0000000'); GO
INSERT INTO [Instructor] VALUES (7, N'Mai Trang', N'Le Thi', N'2005-01-12 00:00:00.0000000'); GO
